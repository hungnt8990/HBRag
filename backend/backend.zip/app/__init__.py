"""HBRag FastAPI application package."""
